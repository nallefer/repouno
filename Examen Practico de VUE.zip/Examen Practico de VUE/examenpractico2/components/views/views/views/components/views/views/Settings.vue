<template>
    <div>
      <h1>Configuración</h1>
      <p>Este es el contenido de la página de configuración.</p>
    </div>
  </template>