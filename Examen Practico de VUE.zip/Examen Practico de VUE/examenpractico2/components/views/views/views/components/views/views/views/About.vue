<template>
    <div>
      <h1>Acerca de</h1>
      <p>Este es el contenido de la página acerca de.</p>
    </div>
  </template>
  