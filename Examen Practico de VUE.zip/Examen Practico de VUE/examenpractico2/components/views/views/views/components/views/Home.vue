<template>
    <div>
      <h1>Inicio</h1>
      <p>Este es el contenido de la página de inicio.</p>
    </div>
  </template>
  